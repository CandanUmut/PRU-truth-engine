# PRU Truth Engine (MVP)

A minimal, **PRU-DB–inspired** truth engine that runs a **7-step verification pipeline**
with **multi-agent moderators** to score claims and generate transparent, reproducible reports.
Designed as a starter repository you can push to GitHub and iterate.

> Vision: a decentralized network where claims, evidence, and sources form a living graph.
> New evidence propagates updates to related claims (self-correcting truth).

## Features (MVP)
- FastAPI backend with SQLite (default) — easy to run.
- Core entities: Claim, Source, Evidence, Scores.
- 7-step scoring pipeline (stubs + basic logic) with pluggable agent runners.
- Transparent JSON reports: per-step scores + rationale skeletons.
- Simple queue interface (in-memory) to simulate async tasks.
- Dockerfile to containerize quickly.

## Roadmap Highlights
- Replace in-memory queue with Redis/Celery for scalability.
- Add vector/BM25 retrieval for corroboration.
- Media integrity checks (pHash/EXIF) and fact-check integrations.
- Expert routing & appeals flow.
- PRU-reactivity: update related claims on new evidence.

## Quickstart

### 1) Local (Python 3.10+)
```bash
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Open: http://127.0.0.1:8000/docs

### 2) Docker
```bash
docker build -t pru-truth-engine-mvp .
docker run -p 8000:8000 pru-truth-engine-mvp
```

## API (high level)
- `POST /claims` → create a claim
- `GET /claims` → list claims
- `POST /evidence` → attach evidence to a claim
- `POST /score/{{claim_id}}` → run the 7-step pipeline for a claim
- `GET /report/{{claim_id}}` → latest combined truth report

## License
MIT
