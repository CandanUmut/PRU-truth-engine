from pydantic import BaseModel, Field
from typing import Optional, List

class ClaimCreate(BaseModel):
    text: str = Field(..., description="Natural language claim")
    topic: Optional[str] = "general"

class ClaimOut(BaseModel):
    id: int
    text: str
    topic: str
    class Config:
        from_attributes = True

class SourceCreate(BaseModel):
    name: str
    domain: Optional[str] = None
    org_type: Optional[str] = "unknown"
    historical_reliability: Optional[float] = 0.5

class EvidenceCreate(BaseModel):
    claim_id: int
    source_id: Optional[int] = None
    url: Optional[str] = None
    media_hash: Optional[str] = None
    excerpt: Optional[str] = None
    stance: Optional[str] = "neutral"

class ScoresOut(BaseModel):
    claim_id: int
    source_score: float
    corroboration_score: float
    media_integrity_score: float
    factcheck_score: float
    logic_score: float
    expert_review_score: float
    temporal_stability_score: float
    truth_score: float
    rationale: str
