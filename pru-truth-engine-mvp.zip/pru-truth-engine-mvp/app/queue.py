from collections import deque

class SimpleQueue:
    def __init__(self):
        self.q = deque()

    def put(self, task):
        self.q.append(task)

    def get(self):
        if self.q:
            return self.q.popleft()
        return None

queue = SimpleQueue()
