from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Dict, Any
from ..db import get_db
from .. import models, schemas

router = APIRouter(prefix="/evidence", tags=["evidence"])

@router.post("")
def add_evidence(payload: schemas.EvidenceCreate, db: Session = Depends(get_db)) -> Dict[str, Any]:
    claim = db.query(models.Claim).get(payload.claim_id)
    if not claim:
        raise HTTPException(status_code=404, detail="Claim not found")
    ev = models.Evidence(
        claim_id=payload.claim_id,
        source_id=payload.source_id,
        url=payload.url,
        media_hash=payload.media_hash,
        excerpt=payload.excerpt,
        stance=payload.stance or "neutral",
    )
    db.add(ev)
    db.commit()
    db.refresh(ev)
    return {"ok": True, "evidence_id": ev.id}
