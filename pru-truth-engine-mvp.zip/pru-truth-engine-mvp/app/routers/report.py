from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Dict, Any
from ..db import get_db
from .. import models

router = APIRouter(prefix="/report", tags=["report"])

@router.get("/{claim_id}")
def get_report(claim_id: int, db: Session = Depends(get_db)) -> Dict[str, Any]:
    claim = db.query(models.Claim).get(claim_id)
    if not claim:
        raise HTTPException(status_code=404, detail="Claim not found")
    scores = db.query(models.Scores).filter_by(claim_id=claim_id).first()
    evidences = db.query(models.Evidence).filter_by(claim_id=claim_id).all()

    return {
        "claim": {"id": claim.id, "text": claim.text, "topic": claim.topic},
        "scores": None if not scores else {
            "source_score": scores.source_score,
            "corroboration_score": scores.corroboration_score,
            "media_integrity_score": scores.media_integrity_score,
            "factcheck_score": scores.factcheck_score,
            "logic_score": scores.logic_score,
            "expert_review_score": scores.expert_review_score,
            "temporal_stability_score": scores.temporal_stability_score,
            "truth_score": scores.truth_score,
            "rationale": scores.rationale,
            "updated_at": scores.updated_at.isoformat() if scores.updated_at else None,
        },
        "evidence_count": len(evidences)
    }
