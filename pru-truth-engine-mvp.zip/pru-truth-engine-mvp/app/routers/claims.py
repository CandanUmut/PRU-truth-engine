from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
from ..db import get_db
from .. import models, schemas

router = APIRouter(prefix="/claims", tags=["claims"])

@router.post("", response_model=schemas.ClaimOut)
def create_claim(payload: schemas.ClaimCreate, db: Session = Depends(get_db)):
    item = models.Claim(text=payload.text, topic=payload.topic or "general")
    db.add(item)
    db.commit()
    db.refresh(item)
    return item

@router.get("", response_model=List[schemas.ClaimOut])
def list_claims(db: Session = Depends(get_db)):
    rows = db.query(models.Claim).order_by(models.Claim.id.desc()).all()
    return rows
