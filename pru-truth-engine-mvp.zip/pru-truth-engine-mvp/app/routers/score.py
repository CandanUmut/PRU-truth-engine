from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Dict, Any
from ..db import get_db
from .. import models
from ..agents import (
    source_agent, corroboration_agent, media_agent, factcheck_agent,
    logic_agent, expert_agent, temporal_agent, combine_scores, rationale_text
)

router = APIRouter(prefix="/score", tags=["score"])

@router.post("/{claim_id}")
def score_claim(claim_id: int, db: Session = Depends(get_db)) -> Dict[str, Any]:
    claim = db.query(models.Claim).get(claim_id)
    if not claim:
        raise HTTPException(status_code=404, detail="Claim not found")
    evidences = db.query(models.Evidence).filter_by(claim_id=claim_id).all()

    s = source_agent(evidences)
    c = corroboration_agent(evidences)
    m = media_agent(evidences)
    f = factcheck_agent(evidences)
    l = logic_agent(claim.text or "")
    e = expert_agent(claim.topic or "general")
    t = temporal_agent()
    truth = combine_scores(s, c, m, f, l, e, t)

    existing = db.query(models.Scores).filter_by(claim_id=claim_id).first()
    if not existing:
        existing = models.Scores(claim_id=claim_id)
        db.add(existing)

    existing.source_score = s
    existing.corroboration_score = c
    existing.media_integrity_score = m
    existing.factcheck_score = f
    existing.logic_score = l
    existing.expert_review_score = e
    existing.temporal_stability_score = t
    existing.truth_score = truth
    existing.rationale = rationale_text({
        "source_score": s, "corroboration_score": c, "media_integrity_score": m,
        "factcheck_score": f, "logic_score": l, "expert_review_score": e,
        "temporal_stability_score": t, "truth_score": truth
    })
    db.commit()
    db.refresh(existing)
    return {"ok": True, "scores": {
        "source_score": s, "corroboration_score": c, "media_integrity_score": m,
        "factcheck_score": f, "logic_score": l, "expert_review_score": e,
        "temporal_stability_score": t, "truth_score": truth,
        "rationale": existing.rationale
    }}
