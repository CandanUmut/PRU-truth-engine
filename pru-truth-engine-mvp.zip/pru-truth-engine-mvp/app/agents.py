from typing import Dict

def clamp(x, a=0.0, b=1.0):
    return max(a, min(b, x))

# --- Stub Agents ---

def source_agent(evidences) -> float:
    vals = []
    for ev in evidences:
        if ev.source and ev.source.historical_reliability is not None:
            vals.append(ev.source.historical_reliability)
    return clamp(sum(vals)/len(vals)) if vals else 0.4

def corroboration_agent(evidences) -> float:
    sup = sum(1 for ev in evidences if (ev.stance or "").lower() == "support")
    ref = sum(1 for ev in evidences if (ev.stance or "").lower() == "refute")
    total = sup + ref
    if total == 0:
        return 0.5
    return clamp(0.5 + (sup - ref) / (2 * total))

def media_agent(evidences) -> float:
    has_media = any(ev.media_hash for ev in evidences)
    return 0.6 if has_media else 0.5

def factcheck_agent(evidences) -> float:
    fact_sites = ("snopes.com", "teyit.org", "factcheck.org", "fullfact.org")
    boost = 0.0
    for ev in evidences:
        if ev.url and any(dom in ev.url for dom in fact_sites):
            boost += 0.15
    return clamp(0.5 + boost)

def logic_agent(text: str) -> float:
    penal = 0.0
    if text.isupper():
        penal += 0.2
    if len(text) > 300:
        penal += 0.05
    return clamp(0.7 - penal)

def expert_agent(topic: str) -> float:
    high = {"medicine", "physics", "math", "finance"}
    low = {"politics", "opinion", "culture"}
    if topic in high:
        return 0.6
    if topic in low:
        return 0.5
    return 0.55

def temporal_agent() -> float:
    return 0.6

def combine_scores(s, c, m, f, l, e, t):
    return clamp(0.22*s + 0.22*c + 0.16*m + 0.14*f + 0.12*l + 0.08*e + 0.06*t)

def rationale_text(scores: Dict[str, float]) -> str:
    verdict = "Şüpheli"
    if scores["truth_score"] >= 0.66:
        verdict = "Doğruya Yakın"
    elif scores["truth_score"] <= 0.34:
        verdict = "Yanlışa Yakın"
    return (
        f"Ön karar: {verdict} (puan: {scores['truth_score']:.2f}). "
        f"Kaynak: {scores['source_score']:.2f}, Bağımsız doğrulama: {scores['corroboration_score']:.2f}, "
        f"Medya: {scores['media_integrity_score']:.2f}, Fact-check: {scores['factcheck_score']:.2f}, "
        f"Mantık: {scores['logic_score']:.2f}, Uzman: {scores['expert_review_score']:.2f}, "
        f"Zamansal: {scores['temporal_stability_score']:.2f}."
    )
