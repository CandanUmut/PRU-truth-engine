from fastapi import FastAPI
from .db import Base, engine
from . import models
from .routers import claims, evidence, score, report

app = FastAPI(title="PRU Truth Engine (MVP)", version="0.1.0")

Base.metadata.create_all(bind=engine)

app.include_router(claims.router)
app.include_router(evidence.router)
app.include_router(score.router)
app.include_router(report.router)

@app.get("/")
def root():
    return {"ok": True, "msg": "PRU Truth Engine MVP is running."}
