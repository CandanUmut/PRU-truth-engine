from sqlalchemy import Column, Integer, String, Text, Float, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from datetime import datetime
from .db import Base

class Claim(Base):
    __tablename__ = "claims"
    id = Column(Integer, primary_key=True, index=True)
    text = Column(Text, nullable=False)
    topic = Column(String(128), default="general")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    evidences = relationship("Evidence", back_populates="claim", cascade="all, delete-orphan", lazy="selectin")
    scores = relationship("Scores", back_populates="claim", cascade="all, delete-orphan", lazy="selectin")

class Source(Base):
    __tablename__ = "sources"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    domain = Column(String(255), nullable=True)
    org_type = Column(String(64), default="unknown")
    historical_reliability = Column(Float, default=0.5)

class Evidence(Base):
    __tablename__ = "evidence"
    id = Column(Integer, primary_key=True, index=True)
    claim_id = Column(Integer, ForeignKey("claims.id"), nullable=False, index=True)
    source_id = Column(Integer, ForeignKey("sources.id"), nullable=True, index=True)
    url = Column(String(1024), nullable=True)
    media_hash = Column(String(128), nullable=True)
    excerpt = Column(Text, nullable=True)
    stance = Column(String(16), default="neutral")  # support|refute|neutral
    created_at = Column(DateTime, default=datetime.utcnow)

    claim = relationship("Claim", back_populates="evidences")
    source = relationship("Source")

class Scores(Base):
    __tablename__ = "scores"
    id = Column(Integer, primary_key=True, index=True)
    claim_id = Column(Integer, ForeignKey("claims.id"), nullable=False, unique=True)
    source_score = Column(Float, default=0.0)
    corroboration_score = Column(Float, default=0.0)
    media_integrity_score = Column(Float, default=0.0)
    factcheck_score = Column(Float, default=0.0)
    logic_score = Column(Float, default=0.0)
    expert_review_score = Column(Float, default=0.0)
    temporal_stability_score = Column(Float, default=0.0)
    truth_score = Column(Float, default=0.0)
    rationale = Column(Text, default="")
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    claim = relationship("Claim", back_populates="scores")
